import { useState, useEffect, useCallback, useRef, createContext, useContext, useReducer } from "react";

/* ================================================================
   constants/config.js
   ================================================================ */
const TRIP_DATE = new Date("2026-08-09T00:00:00");
const STORAGE_KEY = "bali30_v4";
const CONFETTI_COLORS = ["#E8579A","#D4B84A","#2D5FA0","#FF6B4A","#FDF8EC","#1DB954"];

/* ================================================================
   constants/data.js
   ================================================================ */
const VIAJERAS = [
  { id:"v1", emoji:"👩‍🎨", role:"Directora creativa / Fotógrafa" },
  { id:"v2", emoji:"💰", role:"Ministra de Finanzas" },
  { id:"v3", emoji:"🗺️", role:"Guía de Itinerario" },
  { id:"v4", emoji:"🍜", role:"Buscadora de Restaurantes" },
  { id:"v5", emoji:"💖", role:"Consejera Emocional" },
  { id:"v6", emoji:"⏰", role:"Jefa de Puntualidad" },
  { id:"v7", emoji:"🎧", role:"Animadora y DJ Oficial" },
  { id:"v8", emoji:"🏥", role:"Directora de Salud y Supervivencia Tropical" },
];
const RUTA_STOPS = [
  { id:"uluwatu",  name:"Uluwatu",      emoji:"🌊", desc:"Acantilados, templos y surf" },
  { id:"ubud",     name:"Ubud",          emoji:"🌾", desc:"Arrozales, yoga y cultura" },
  { id:"gili",     name:"Gili Islands",  emoji:"🏝️", desc:"Snorkel, tortugas y paraíso" },
  { id:"komodo",   name:"Komodo",        emoji:"🦎", desc:"Dragones, senderismo y vistas" },
  { id:"canggu",   name:"Canggu",        emoji:"🌅", desc:"Sunsets, fiesta y despedida" },
];
const DETAIL_TYPES = [
  { key:"hotel",       icon:"🏨", label:"Alojamiento" },
  { key:"restaurante", icon:"🍽️", label:"Restaurantes" },
  { key:"actividad",   icon:"🎯", label:"Actividades" },
  { key:"notas",       icon:"📝", label:"Notas" },
];
const RETOS_BASE = [
  "Ver un amanecer",
  "Bañarnos en el mar por la noche",
  "Probar 3 platos nuevos",
  "Aprender 3 palabras en indonesio",
  "8 fotos grupales para los siguientes cumpleaños",
  "Clase de yoga por Begonxu",
  "Ver un atardecer",
  "Hacer cápsula del tiempo",
  "Noche total black — RIP 20s",
  "Diseñarnos una camiseta del viaje",
  "Grabar el blog de los 30",
  "Soplar las velas todas juntas",
];
const NORMAS = [
  { id:"n1",  icon:"✅", text:"Todas vuelven a casa vivas" },
  { id:"n2",  icon:"😂", text:"Reír una vez al día obligatoriamente" },
  { id:"n3",  icon:"🤸", text:"Predisposición a adaptarse" },
  { id:"n4",  icon:"⏱️", text:"Los enfados duran 10 minutos" },
  { id:"n5",  icon:"🍔", text:"Si una quiere comer, se come" },
  { id:"n6",  icon:"🎉", text:"Si una quiere fiesta, se intenta" },
  { id:"n7",  icon:"📸", text:"Las fotos son obligatorias" },
  { id:"n8",  icon:"👯", text:"Nadie se pierde" },
  { id:"n9",  icon:"🛂", text:"Nadie pierde el pasaporte" },
  { id:"n10", icon:"⏰", text:"Fluimos pero somos puntuales" },
  { id:"n11", icon:"🌙", text:"Charlas sanatorias nocturnas" },
  { id:"n12", icon:"🤫", text:"Lo que pasa en Bali, se queda en Bali" },
];
const NAV_ITEMS = [
  { id:"home",        label:"Home" },
  { id:"viajeras",    label:"Viajeras" },
  { id:"ruta",        label:"Ruta" },
  { id:"retos",       label:"Retos" },
  { id:"normas",      label:"Normas" },
  { id:"fotos",       label:"Fotos" },
  { id:"reflexiones", label:"Diario" },
  { id:"musica",      label:"Música" },
];

/* ================================================================
   constants/tokens.js
   ================================================================ */
const T = {
  yellow:      "#D4B84A",
  yellowLight: "#E8D07A",
  pink:        "#E8579A",
  blue:        "#2D5FA0",
  cream:       "#FDF8EC",
  dark:        "#1A1A1A",
  coral:       "#FF6B4A",
  green:       "#2A8A4A",
  greenLight:  "#C8F0D0",
  spotify:     "#1DB954",
};

/* ================================================================
   hooks/useCountdown.js
   ================================================================ */
function useCountdown(targetDate: Date) {
  const calc = useCallback(() => {
    const diff = targetDate.getTime() - Date.now();
    if (diff <= 0) return null;
    return {
      days:    Math.floor(diff / 864e5),
      hours:   Math.floor((diff % 864e5) / 36e5),
      minutes: Math.floor((diff % 36e5) / 6e4),
      seconds: Math.floor((diff % 6e4) / 1e3),
    };
  }, [targetDate]);
  const [time, setTime] = useState(calc);
  useEffect(() => {
    const id = setInterval(() => setTime(calc()), 1000);
    return () => clearInterval(id);
  }, [calc]);
  return time;
}

/* ================================================================
   hooks/useConfetti.js
   ================================================================ */
function useConfetti() {
  return useCallback((count = 90) => {
    for (let i = 0; i < count; i++) {
      setTimeout(() => {
        const el = document.createElement("div");
        const color = CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)];
        const size  = 6 + Math.random() * 8;
        Object.assign(el.style, {
          position:         "fixed",
          left:             `${Math.random() * 100}vw`,
          top:              "-20px",
          width:            `${size}px`,
          height:           `${size}px`,
          background:       color,
          borderRadius:     "2px",
          pointerEvents:    "none",
          zIndex:           "9999",
          animation:        `confettiFall ${1.5 + Math.random() * 2}s linear forwards`,
        });
        document.body.appendChild(el);
        setTimeout(() => el.remove(), 3500);
      }, i * 25);
    }
  }, []);
}

/* ================================================================
   context/AppContext.js
   ================================================================ */
const AppContext = createContext<any>(null);
const initialState = {
  retosChecked:    [] as number[],
  retosCustom:     [] as string[],
  normasCulpables: {} as Record<string, string[]>,
  reflexiones:     [] as any[],
  rutaDetails:     {} as Record<string, any>,
};
function appReducer(state: typeof initialState, action: any) {
  switch (action.type) {
    case "RETO_TOGGLE": {
      const idx = state.retosChecked.indexOf(action.index);
      return {
        ...state,
        retosChecked: idx > -1
          ? state.retosChecked.filter(i => i !== action.index)
          : [...state.retosChecked, action.index],
      };
    }
    case "RETO_ADD":
      return { ...state, retosCustom: [...state.retosCustom, action.text] };
    case "RETO_REMOVE": {
      const ci = action.index - RETOS_BASE.length;
      return {
        ...state,
        retosCustom:  state.retosCustom.filter((_: string, i: number) => i !== ci),
        retosChecked: state.retosChecked
          .filter((x: number) => x !== action.index)
          .map((x: number) => x > action.index ? x - 1 : x),
      };
    }
    case "NORMA_ADD_CULPABLE": {
      const prev = state.normasCulpables[action.normaId] || [];
      return {
        ...state,
        normasCulpables: { ...state.normasCulpables, [action.normaId]: [...prev, action.name] },
      };
    }
    case "NORMA_REMOVE_CULPABLE": {
      const list = (state.normasCulpables[action.normaId] || []).filter((_, i) => i !== action.index);
      return {
        ...state,
        normasCulpables: { ...state.normasCulpables, [action.normaId]: list },
      };
    }
    case "REFLEXION_ADD":
      return { ...state, reflexiones: [action.item, ...state.reflexiones] };
    case "REFLEXION_REMOVE":
      return { ...state, reflexiones: state.reflexiones.filter((_, i) => i !== action.index) };
    case "RUTA_ADD_DETAIL": {
      const stop    = state.rutaDetails[action.stopId] || {};
      const current = stop[action.key] || [];
      return {
        ...state,
        rutaDetails: {
          ...state.rutaDetails,
          [action.stopId]: { ...stop, [action.key]: [...current, action.value] },
        },
      };
    }
    case "RUTA_REMOVE_DETAIL": {
      const stop    = state.rutaDetails[action.stopId] || {};
      const updated = (stop[action.key] || []).filter((_: any, i: number) => i !== action.index);
      return {
        ...state,
        rutaDetails: {
          ...state.rutaDetails,
          [action.stopId]: { ...stop, [action.key]: updated },
        },
      };
    }
    case "HYDRATE": return { ...state, ...action.payload };
    default: return state;
  }
}
function AppProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);
  const [fotos, setFotos] = useState<any[]>([]);
  const [activeSection, setActiveSection] = useState("home");
  const hydrated = useRef(false);
  
  useEffect(() => {
    if (hydrated.current) return;
    hydrated.current = true;
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const data = JSON.parse(raw);
        dispatch({ type: "HYDRATE", payload: data.state || data });
        if (data.fotos) setFotos(data.fotos);
      }
    } catch {}
  }, []);
  
  useEffect(() => {
    if (!hydrated.current) return;
    try { 
      localStorage.setItem(STORAGE_KEY, JSON.stringify({ state, fotos })); 
    } catch {}
  }, [state, fotos]);

  const exportData = useCallback(() => {
    return JSON.stringify({ state, fotos, exportedAt: new Date().toISOString() });
  }, [state, fotos]);

  const importData = useCallback((jsonString: string) => {
    try {
      const data = JSON.parse(jsonString);
      if (data.state) dispatch({ type: "HYDRATE", payload: data.state });
      if (data.fotos) setFotos(data.fotos);
      return true;
    } catch {
      return false;
    }
  }, []);
  
  const value = { state, dispatch, fotos, setFotos, activeSection, setActiveSection, exportData, importData };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used inside AppProvider");
  return ctx;
}

/* ================================================================
   components/ui/GlobalStyles.jsx
   ================================================================ */
function GlobalStyles() {
  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Playfair+Display:ital,wght@0,400;0,700;1,400&family=DM+Sans:wght@300;400;500;600&display=swap');
      *, *::before, *::after { margin:0; padding:0; box-sizing:border-box; }
      html { -webkit-text-size-adjust:100%; }
      body {
        background:${T.yellow};
        font-family:'DM Sans',sans-serif;
        color:${T.dark};
        min-height:100vh;
        overflow-x:hidden;
        cursor: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 24 24' fill='none' stroke='%23E8579A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z'/></svg>") 4 4, auto;
      }
      button, a, [role="button"], [onclick] {
        font-family:'DM Sans',sans-serif;
        cursor: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='32' height='32' viewBox='0 0 24 24' fill='%23E8579A' stroke='%231A1A1A' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'><path d='M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z'/></svg>") 4 4, pointer;
        border:none;
        background:none;
      }
      input, textarea {
        font-family:'DM Sans',sans-serif; font-size:14px;
        border:2px solid ${T.dark}; border-radius:8px;
        padding:8px 12px; background:#fff; outline:none;
        transition:border-color .2s; width:100%;
        cursor: text;
      }
      input:focus, textarea:focus { border-color:${T.blue}; }
      textarea { resize:vertical; min-height:80px; }
      @keyframes confettiFall {
        from { transform:translateY(-20px) rotate(0deg);   opacity:1; }
        to   { transform:translateY(105vh) rotate(720deg); opacity:0; }
      }
      @keyframes fadeUp {
        from { opacity:0; transform:translateY(10px); }
        to   { opacity:1; transform:translateY(0); }
      }
      @keyframes planeWiggle {
        0%, 100% { transform: rotate(-2deg); }
        50% { transform: rotate(2deg); }
      }
      .fade-up { animation:fadeUp .3s ease both; }
    `}</style>
  );
}

/* ================================================================
   UI Components
   ================================================================ */
function Card({ children, style, className = "" }: any) {
  return (
    <div className={className} style={{
      background: T.cream,
      border: `3px solid ${T.dark}`,
      borderRadius: 16,
      padding: "16px 18px",
      boxShadow: `4px 4px 0 ${T.dark}`,
      marginBottom: 12,
      ...style,
    }}>
      {children}
    </div>
  );
}

const BTN_VARIANTS = {
  primary: {
    background: T.pink,
    border: `3px solid ${T.dark}`,
    color: "#fff",
    boxShadow: `3px 3px 0 ${T.dark}`,
    borderRadius: 12,
    padding: "9px 18px",
    fontSize: 13,
    fontWeight: 700,
  },
  secondary: {
    background: T.cream,
    border: `2px solid ${T.dark}`,
    color: T.dark,
    boxShadow: `2px 2px 0 ${T.dark}`,
    borderRadius: 10,
    padding: "7px 14px",
    fontSize: 12,
    fontWeight: 600,
  },
  ghost: {
    background: "none",
    border: "2px dashed #ccc",
    color: "#999",
    borderRadius: 8,
    padding: "5px 10px",
    fontSize: 11,
    width: "100%",
    marginTop: 6,
  },
  icon: {
    background: "none",
    color: "#ccc",
    fontSize: 14,
    padding: "2px 4px",
    flexShrink: 0,
    transition: "color .15s",
  },
};
function Button({ variant = "primary", onClick, children, style, ...props }: any) {
  const base = BTN_VARIANTS[variant as keyof typeof BTN_VARIANTS] || BTN_VARIANTS.primary;
  const [hov, setHov] = useState(false);
  const hoverShift = variant === "primary"
    ? { transform:"translate(-1px,-1px)", boxShadow:`4px 4px 0 ${T.dark}` }
    : variant === "secondary"
    ? { transform:"translate(-1px,-1px)", boxShadow:`3px 3px 0 ${T.dark}` }
    : variant === "ghost"
    ? { borderColor:T.blue, color:T.blue, background:"rgba(45,95,160,0.05)" }
    : { color: T.coral };
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{ ...base, ...(hov ? hoverShift : {}), transition:"all .15s", ...style }}
      {...props}
    >
      {children}
    </button>
  );
}

function Badge({ children }: any) {
  return (
    <span style={{
      display:"block", width:"fit-content", margin:"0 auto 20px",
      padding:"4px 14px", borderRadius:20,
      background:T.dark, color:T.yellow,
      fontSize:9, fontWeight:700, letterSpacing:2, textTransform:"uppercase",
    }}>
      {children}
    </span>
  );
}

function SectionTitle({ children }: any) {
  return (
    <h2 style={{
      fontFamily:"'Bebas Neue',sans-serif",
      fontSize:50, letterSpacing:3,
      color:T.cream, textAlign:"center", marginBottom:6,
    }}>
      {children}
    </h2>
  );
}

function PageWrap({ children }: any) {
  return <div style={{ maxWidth:480, margin:"0 auto" }}>{children}</div>;
}

function DashedBox({ label, labelColor = T.blue, children, style }: any) {
  return (
    <div style={{
      background:T.cream, border:`3px dashed ${T.dark}`,
      borderRadius:14, padding:"14px 16px",
      boxShadow:`3px 3px 0 ${T.dark}`, ...style,
    }}>
      {label && (
        <p style={{
          fontSize:11, fontWeight:700, letterSpacing:1,
          textTransform:"uppercase", color:labelColor, marginBottom:10,
        }}>
          {label}
        </p>
      )}
      {children}
    </div>
  );
}

function InputRow({ placeholder, onSubmit, btnLabel = "Añadir", ariaLabel, style }: any) {
  const [val, setVal] = useState("");
  const handleSubmit = () => { if (!val.trim()) return; onSubmit(val.trim()); setVal(""); };
  return (
    <div style={{ display:"flex", gap:8, ...style }}>
      <input
        value={val}
        onChange={e => setVal(e.target.value)}
        onKeyDown={e => e.key === "Enter" && handleSubmit()}
        placeholder={placeholder}
        aria-label={ariaLabel || placeholder}
      />
      <Button variant="primary" onClick={handleSubmit}>{btnLabel}</Button>
    </div>
  );
}

function EmptyState({ icon, text }: any) {
  return (
    <div style={{ textAlign:"center", padding:"40px 20px" }}>
      <div style={{ fontSize:48, marginBottom:10 }}>{icon}</div>
      <p style={{
        fontFamily:"'Playfair Display',serif", fontStyle:"italic",
        color:T.cream, fontSize:15,
      }}>{text}</p>
    </div>
  );
}

function Nav() {
  const { activeSection, setActiveSection } = useApp();
  return (
    <nav style={{
      position:"fixed", top:0, left:0, right:0, zIndex:300,
      height:54, background:T.yellow, borderBottom:`3px solid ${T.dark}`,
      display:"flex", alignItems:"center", gap:8, padding:"0 12px",
    }}>
      <div style={{
        fontFamily:"'Bebas Neue',sans-serif",
        fontSize:24, letterSpacing:2, color:T.pink, flexShrink:0,
      }}>
        BALI<span style={{ color:T.cream }}>30</span>
      </div>
      <div style={{
        display:"flex", gap:2, overflowX:"auto",
        scrollbarWidth:"none",
      }}>
        {NAV_ITEMS.map(item => {
          const isActive = activeSection === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveSection(item.id)}
              style={{
                background: isActive ? T.dark : "none",
                color:      isActive ? T.yellow : T.dark,
                border:     "none",
                fontSize:10, fontWeight:600, letterSpacing:1,
                textTransform:"uppercase",
                padding:"5px 9px", borderRadius:20,
                whiteSpace:"nowrap", transition:"all .2s",
                cursor:"pointer",
              }}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

/* ================================================================
   Views
   ================================================================ */
function HomeView() {
  const time = useCountdown(TRIP_DATE);
  const confetti = useConfetti();
  const { exportData, importData } = useApp();
  
  const handleShare = async () => {
    const data = exportData();
    const blob = new Blob([data], { type: 'application/json' });
    const file = new File([blob], 'bali30-datos.json', { type: 'application/json' });
    
    if (navigator.share && navigator.canShare?.({ files: [file] })) {
      try {
        await navigator.share({
          title: 'BALI 30 - Datos del viaje',
          text: 'Importa estos datos en tu app BALI 30 para sincronizar',
          files: [file]
        });
      } catch {}
    } else {
      // Fallback: download
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'bali30-datos.json';
      a.click();
      URL.revokeObjectURL(url);
      alert('Datos descargados. Compártelos por WhatsApp y las demás pueden importarlos en la app.');
    }
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e: any) => {
      const file = e.target.files[0];
      if (!file) return;
      const text = await file.text();
      if (importData(text)) {
        confetti();
        alert('¡Datos importados! Ya estáis sincronizadas ✈️');
      } else {
        alert('Error al importar');
      }
    };
    input.click();
  };
  
  return (
    <div className="fade-up" style={{
      display:"flex", flexDirection:"column",
      alignItems:"center", justifyContent:"center",
      textAlign:"center", minHeight:"90vh",
    }}>
      <h1 style={{
        fontFamily:"'Bebas Neue',sans-serif",
        fontSize:"clamp(90px,26vw,150px)", lineHeight:0.85,
        color:T.pink, letterSpacing:4,
      }}>
        BALI<span style={{ color:T.cream, fontSize:"clamp(65px,17vw,115px)" }}>30</span>
      </h1>
      <p style={{
        fontFamily:"'Playfair Display',serif", fontStyle:"italic",
        fontSize:"clamp(14px,4vw,20px)", color:T.cream,
        margin:"14px 0 5px", letterSpacing:1,
      }}>
        Esto no es solo un viaje, es EL viaje
      </p>
      <p style={{
        fontSize:11, fontWeight:600, letterSpacing:3,
        textTransform:"uppercase", color:T.dark,
        opacity:0.65, marginBottom:32,
      }}>
        Bali Girls · Agosto 2026
      </p>
      
      <div style={{
        background:T.blue, border:`3px solid ${T.dark}`,
        borderRadius:20, boxShadow:`6px 6px 0 ${T.dark}`,
        padding:"24px 28px", width:"100%", maxWidth:360, marginBottom:28,
      }}>
        <p style={{ fontSize:10, fontWeight:600, letterSpacing:3, textTransform:"uppercase", color:T.yellowLight, marginBottom:14 }}>
          Faltan...
        </p>
        {time ? (
          <div style={{ display:"flex", gap:6, justifyContent:"center", flexWrap:"wrap" }}>
            {[
              { v:time.days,    l:"días"  },
              { v:time.hours,   l:"horas" },
              { v:time.minutes, l:"min"   },
              { v:time.seconds, l:"seg"   },
            ].map(({ v, l }) => (
              <div key={l} style={{
                display:"flex", flexDirection:"column", alignItems:"center",
                background:"rgba(255,255,255,0.12)", borderRadius:10,
                padding:"10px 12px", minWidth:56,
              }}>
                <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:40, lineHeight:1, color:T.cream }}>
                  {String(v).padStart(2,"0")}
                </span>
                <span style={{ fontSize:8, letterSpacing:2, textTransform:"uppercase", color:T.yellowLight, marginTop:3 }}>
                  {l}
                </span>
              </div>
            ))}
          </div>
        ) : (
          <p style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:26, letterSpacing:2, color:T.cream }}>
            ¡ESTAMOS EN BALI! 🌴
          </p>
        )}
        <p style={{ fontFamily:"'Playfair Display',serif", fontStyle:"italic", fontSize:12, color:T.yellowLight, marginTop:14 }}>
          Domingo, 9 de agosto de 2026
        </p>
      </div>
      <button
        onClick={() => confetti()}
        style={{
          background:T.pink, border:`3px solid ${T.dark}`, color:"#fff",
          fontFamily:"'Bebas Neue',sans-serif", fontSize:20, letterSpacing:2,
          padding:"12px 28px", borderRadius:14, boxShadow:`4px 4px 0 ${T.dark}`,
          cursor:"pointer", marginBottom:16, transition:"all .15s",
        }}
        onMouseEnter={e => Object.assign(e.currentTarget.style,{ transform:"translate(-2px,-2px)", boxShadow:`6px 6px 0 ${T.dark}` })}
        onMouseLeave={e => Object.assign(e.currentTarget.style,{ transform:"", boxShadow:`4px 4px 0 ${T.dark}` })}
      >
        ¡BALI IS COMING! ✨
      </button>
      
      <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
        <button
          onClick={handleShare}
          style={{
            background: T.cream,
            border: `2px solid ${T.dark}`,
            color: T.dark,
            borderRadius: 10,
            padding: '8px 14px',
            fontSize: 11,
            fontWeight: 600,
            boxShadow: `2px 2px 0 ${T.dark}`,
            cursor: 'pointer',
          }}
        >
          📤 Compartir datos
        </button>
        <button
          onClick={handleImport}
          style={{
            background: T.cream,
            border: `2px solid ${T.dark}`,
            color: T.dark,
            borderRadius: 10,
            padding: '8px 14px',
            fontSize: 11,
            fontWeight: 600,
            boxShadow: `2px 2px 0 ${T.dark}`,
            cursor: 'pointer',
          }}
        >
          📥 Importar
        </button>
      </div>
      <p style={{ fontSize: 10, color: T.dark, opacity: 0.6, marginTop: 8, maxWidth: 280 }}>
        Las 8 podéis instalar la app y compartir el archivo para sincronizar retos y fotos
      </p>
    </div>
  );
}

function ViajerasView() {
  return (
    <div className="fade-up">
      <SectionTitle>LAS VIAJERAS</SectionTitle>
      <Badge>8 amigas · 1 misión</Badge>
      <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:12, maxWidth:480, margin:"0 auto" }}>
        {VIAJERAS.map(v => (
          <div key={v.id} style={{
            background:T.cream, border:`3px solid ${T.dark}`,
            borderRadius:16, padding:"18px 14px", textAlign:"center",
            boxShadow:`4px 4px 0 ${T.dark}`, transition:"all .15s",
          }}>
            <div style={{ fontSize:34, marginBottom:8 }}>{v.emoji}</div>
            <p style={{
              fontFamily:"'Bebas Neue',sans-serif", fontSize:14,
              letterSpacing:1, color:T.blue, lineHeight:1.3,
            }}>{v.role}</p>
          </div>
        ))}
      </div>
      <p style={{
        fontFamily:"'Playfair Display',serif", fontStyle:"italic",
        fontSize:15, color:T.cream, lineHeight:1.8, textAlign:"center",
        maxWidth:380, margin:"22px auto 0", padding:"0 12px",
      }}>
        "En 5 años no nos acordaremos de cuánto nos costó el vuelo o los hoteles.
        Pero en cambio recordaremos este viaje toda la vida."
      </p>
    </div>
  );
}

function RutaView() {
  const { state, dispatch } = useApp();
  const addDetail = useCallback((stopId: string, key: string, value: string) => {
    dispatch({ type:"RUTA_ADD_DETAIL", stopId, key, value });
  }, [dispatch]);
  const removeDetail = useCallback((stopId: string, key: string, index: number) => {
    dispatch({ type:"RUTA_REMOVE_DETAIL", stopId, key, index });
  }, [dispatch]);
  
  return (
    <div className="fade-up">
      <SectionTitle>RUTA</SectionTitle>
      <Badge>No definitiva · Ve completándola</Badge>
      <PageWrap>
        {RUTA_STOPS.map((stop, i) => {
          const details = state.rutaDetails[stop.id] || {};
          return (
            <div key={stop.id} style={{
              background:T.cream, border:`3px solid ${T.dark}`,
              borderRadius:16, padding:"14px 16px",
              marginBottom:14, boxShadow:`4px 4px 0 ${T.dark}`,
            }}>
              <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:12 }}>
                <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:30, color:T.yellow, minWidth:30 }}>
                  0{i + 1}
                </span>
                <div style={{ flex:1 }}>
                  <p style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:22, letterSpacing:2 }}>{stop.name}</p>
                  <p style={{ fontSize:11, color:"#888" }}>{stop.desc}</p>
                </div>
                <span style={{ fontSize:24 }}>{stop.emoji}</span>
              </div>
              {DETAIL_TYPES.map(dt => {
                const items = details[dt.key] || [];
                return (
                  <div key={dt.key} style={{ marginBottom:10 }}>
                    <div style={{ display:"flex", alignItems:"center", gap:8, marginBottom:4 }}>
                      <span style={{ fontSize:15 }}>{dt.icon}</span>
                      <span style={{ fontSize:9, fontWeight:700, letterSpacing:"1.5px", textTransform:"uppercase", color:T.blue }}>
                        {dt.label}
                      </span>
                    </div>
                    <div style={{ paddingLeft:23 }}>
                      {items.map((item: string, idx: number) => (
                        <div key={idx} style={{ display:"flex", alignItems:"center", gap:6, marginBottom:3 }}>
                          <span style={{ fontSize:13, color:"#444", flex:1 }}>• {item}</span>
                          <button onClick={() => removeDetail(stop.id, dt.key, idx)} style={{ background:"none", border:"none", fontSize:12, color:"#ccc", cursor:"pointer" }}>✕</button>
                        </div>
                      ))}
                      <InputRow 
                        placeholder={`Añadir ${dt.label.toLowerCase()}...`}
                        onSubmit={(val: string) => addDetail(stop.id, dt.key, val)}
                        btnLabel="+"
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })}
      </PageWrap>
    </div>
  );
}

function RetosView() {
  const { state, dispatch } = useApp();
  const confetti = useConfetti();
  const allRetos = [...RETOS_BASE, ...state.retosCustom];
  const doneCount = state.retosChecked.length;
  const pct = allRetos.length ? Math.round((doneCount / allRetos.length) * 100) : 0;
  
  const toggle = useCallback((index: number) => {
    dispatch({ type:"RETO_TOGGLE", index });
    const willComplete = !state.retosChecked.includes(index) &&
      state.retosChecked.length + 1 === allRetos.length;
    if (willComplete) confetti();
  }, [dispatch, state.retosChecked, allRetos.length, confetti]);
  
  return (
    <div className="fade-up">
      <SectionTitle>RETOS</SectionTitle>
      <PageWrap>
        <Card>
          <div style={{ display:"flex", justifyContent:"space-between", marginBottom:8 }}>
            <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:18, letterSpacing:1 }}>Progreso del grupo</span>
            <span style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:18, color:T.blue }}>{doneCount} / {allRetos.length}</span>
          </div>
          <div style={{ height:10, background:"#e0e0e0", borderRadius:10, overflow:"hidden" }}>
            <div style={{
              height:"100%", borderRadius:10,
              width:`${pct}%`, background:T.blue,
              transition:"width .4s ease",
            }} />
          </div>
        </Card>
        
        {allRetos.map((text, i) => {
          const isDone   = state.retosChecked.includes(i);
          const isCustom = i >= RETOS_BASE.length;
          return (
            <div
              key={i}
              onClick={() => toggle(i)}
              style={{
                background:  isDone ? T.greenLight : T.cream,
                border:      `3px solid ${isDone ? T.green : T.dark}`,
                borderRadius:14, padding:"12px 16px",
                display:"flex", alignItems:"center", gap:12,
                boxShadow:   `3px 3px 0 ${isDone ? T.green : T.dark}`,
                cursor:"pointer", transition:"all .2s",
                marginBottom:8,
              }}
            >
              <span style={{
                width:26, height:26, minWidth:26,
                border:`3px solid ${isDone ? T.green : T.dark}`,
                borderRadius:7,
                background: isDone ? T.green : "#fff",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:14, color:"#fff",
              }}>
                {isDone ? "✓" : ""}
              </span>
              <span style={{
                fontSize:14, flex:1,
                textDecoration: isDone ? "line-through" : "none",
                color: isDone ? T.green : T.dark,
                fontWeight: isDone ? 600 : 400,
              }}>
                {text}
              </span>
              {isCustom && (
                <button
                  onClick={e => { e.stopPropagation(); dispatch({ type:"RETO_REMOVE", index:i }); }}
                  style={{ background:"none", border:"none", fontSize:14, color:"#ccc", cursor:"pointer" }}
                >✕</button>
              )}
            </div>
          );
        })}
        
        <DashedBox label="✨ Proponer nuevo reto" style={{ marginTop:12 }}>
          <InputRow placeholder="Escribe un reto nuevo..." onSubmit={(text: string) => dispatch({ type:"RETO_ADD", text })} />
        </DashedBox>
      </PageWrap>
    </div>
  );
}

function NormasView() {
  const { state, dispatch } = useApp();
  
  return (
    <div className="fade-up">
      <SectionTitle>NORMAS</SectionTitle>
      <Badge>Toca ✏️ para reportar infractoras</Badge>
      <PageWrap>
        {NORMAS.map(norma => {
          const culpables = state.normasCulpables[norma.id] || [];
          return (
            <div key={norma.id} style={{
              background:T.cream, border:`3px solid ${T.dark}`,
              borderRadius:14, padding:"14px 16px",
              boxShadow:`3px 3px 0 ${T.dark}`, marginBottom:8,
            }}>
              <div style={{ display:"flex", alignItems:"center", gap:10 }}>
                <span style={{ fontSize:20, minWidth:24, textAlign:"center" }}>{norma.icon}</span>
                <p style={{ fontSize:14, flex:1 }}>{norma.text}</p>
              </div>
              
              {culpables.length > 0 && (
                <div style={{ marginTop:10, paddingTop:10, borderTop:"2px dashed #e0e0e0" }}>
                  <p style={{ fontSize:9, fontWeight:700, letterSpacing:"1.5px", textTransform:"uppercase", color:T.coral, marginBottom:6 }}>
                    Infractoras:
                  </p>
                  <div style={{ display:"flex", flexWrap:"wrap", gap:5, marginBottom:8 }}>
                    {culpables.map((name: string, j: number) => (
                      <span key={j} style={{
                        display:"flex", alignItems:"center", gap:5,
                        background:"#FFE8E0", border:`2px solid ${T.coral}`,
                        borderRadius:20, padding:"3px 10px",
                        fontSize:12, fontWeight:500, color:T.coral,
                      }}>
                        {name}
                        <button onClick={() => dispatch({ type:"NORMA_REMOVE_CULPABLE", normaId:norma.id, index:j })} style={{ background:"none",border:"none",cursor:"pointer",fontSize:12,color:T.coral }}>✕</button>
                      </span>
                    ))}
                  </div>
                </div>
              )}
              
              <div style={{ display:"flex", gap:6, marginTop:8 }}>
                <input
                  placeholder="¿Quién ha incumplido?"
                  style={{ flex:1, fontSize:12, padding:"5px 10px" }}
                  onKeyDown={e => { 
                    if (e.key==="Enter" && (e.target as HTMLInputElement).value.trim()) { 
                      dispatch({ type:"NORMA_ADD_CULPABLE", normaId:norma.id, name:(e.target as HTMLInputElement).value.trim() }); 
                      (e.target as HTMLInputElement).value=""; 
                    }
                  }}
                />
                <button
                  onClick={e => {
                    const inp = (e.currentTarget.previousSibling as HTMLInputElement);
                    if (inp.value.trim()) { 
                      dispatch({ type:"NORMA_ADD_CULPABLE", normaId:norma.id, name:inp.value.trim() }); 
                      inp.value=""; 
                    }
                  }}
                  style={{ background:T.coral, border:`2px solid ${T.dark}`, color:"#fff", borderRadius:8, padding:"5px 10px", fontSize:12, fontWeight:700, cursor:"pointer" }}
                >
                  +1
                </button>
              </div>
            </div>
          );
        })}
      </PageWrap>
    </div>
  );
}

function FotosView() {
  const { fotos, setFotos } = useApp();
  const inputRef = useRef<HTMLInputElement>(null);
  const [dragging, setDragging] = useState(false);
  
  const processFiles = useCallback((files: FileList) => {
    Array.from(files).forEach(file => {
      if (!file.type.startsWith("image/")) return;
      const reader = new FileReader();
      reader.onload = e => setFotos((prev: any[]) => [...prev, {
        src:  e.target?.result,
        date: new Date().toLocaleDateString("es-ES", { day:"numeric", month:"short", year:"numeric" }),
      }]);
      reader.readAsDataURL(file);
    });
  }, [setFotos]);
  
  return (
    <div className="fade-up">
      <SectionTitle>FOTOS</SectionTitle>
      <Badge>Álbum del viaje</Badge>
      <PageWrap>
        <div
          onClick={() => inputRef.current?.click()}
          onDragOver={e => { e.preventDefault(); setDragging(true); }}
          onDragLeave={() => setDragging(false)}
          onDrop={e => { e.preventDefault(); setDragging(false); processFiles(e.dataTransfer.files); }}
          style={{
            background: dragging ? "#fff8f4" : T.cream,
            border:`3px dashed ${dragging ? T.pink : T.dark}`,
            borderRadius:16, padding:"28px 20px", textAlign:"center",
            cursor:"pointer", transition:"all .2s", marginBottom:16,
            boxShadow:`4px 4px 0 ${T.dark}`,
          }}
        >
          <div style={{ fontSize:40, marginBottom:10 }}>📸</div>
          <p style={{ fontFamily:"'Bebas Neue',sans-serif", fontSize:18, letterSpacing:2 }}>SUBIR FOTO</p>
          <span style={{ fontSize:12, color:"#888", marginTop:4, display:"block" }}>
            {dragging ? "¡Suelta aquí!" : "Toca o arrastra para añadir fotos"}
          </span>
        </div>
        <input ref={inputRef} type="file" accept="image/*" multiple hidden
          onChange={e => { if (e.target.files) { processFiles(e.target.files); e.target.value=""; } }} />
        
        {fotos.length === 0 ? (
          <EmptyState icon="📷" text="Las fotos del viaje aparecerán aquí" />
        ) : (
          <div style={{ display:"grid", gridTemplateColumns:"repeat(2,1fr)", gap:10 }}>
            {fotos.map((f: any, i: number) => (
              <div key={i} style={{
                background:T.cream, border:`3px solid ${T.dark}`,
                borderRadius:14, overflow:"hidden",
                boxShadow:`3px 3px 0 ${T.dark}`, position:"relative",
              }}>
                <img src={f.src} alt="" loading="lazy"
                  style={{ width:"100%", aspectRatio:"1/1", objectFit:"cover", display:"block" }} />
                <p style={{ padding:"7px 10px", fontSize:11, color:"#666", borderTop:"2px solid #eee" }}>{f.date}</p>
                <button
                  onClick={() => setFotos((prev: any[]) => prev.filter((_, idx) => idx !== i))}
                  style={{
                    position:"absolute", top:6, right:6,
                    background:"rgba(0,0,0,0.65)", color:"#fff",
                    border:"none", borderRadius:"50%",
                    width:24, height:24, fontSize:12, cursor:"pointer",
                  }}
                >✕</button>
              </div>
            ))}
          </div>
        )}
      </PageWrap>
    </div>
  );
}

function DiarioView() {
  const { state, dispatch } = useApp();
  const [autor, setAutor]   = useState("");
  const [lugar, setLugar]   = useState("");
  const [texto, setTexto]   = useState("");
  
  const handleAdd = () => {
    if (!texto.trim()) return;
    dispatch({ type:"REFLEXION_ADD", item: {
      autor: autor.trim() || "Anónima",
      lugar: lugar.trim() || "Bali",
      texto: texto.trim(),
      fecha: new Date().toLocaleDateString("es-ES", { day:"numeric", month:"short" }),
    }});
    setAutor(""); setLugar(""); setTexto("");
  };
  
  return (
    <div className="fade-up">
      <SectionTitle>DIARIO</SectionTitle>
      <Badge>Reflexiones del viaje</Badge>
      <PageWrap>
        <DashedBox label="✍️ Nueva reflexión" labelColor={T.pink} style={{ marginBottom:16 }}>
          <div style={{ display:"flex", gap:8, marginBottom:8 }}>
            <input value={autor} onChange={e=>setAutor(e.target.value)} placeholder="Tu nombre" style={{ maxWidth:130 }} />
            <input value={lugar} onChange={e=>setLugar(e.target.value)} placeholder="Lugar (ej: Ubud)" />
          </div>
          <textarea value={texto} onChange={e=>setTexto(e.target.value)}
            placeholder="Escribe tu reflexión, pensamiento o momento especial..." />
          <div style={{ marginTop:8, display:"flex", justifyContent:"flex-end" }}>
            <Button variant="primary" onClick={handleAdd}>Guardar 💌</Button>
          </div>
        </DashedBox>
        {state.reflexiones.length === 0 ? (
          <EmptyState icon="💭" text="Vuestras reflexiones aparecerán aquí" />
        ) : (
          state.reflexiones.map((r: any, i: number) => (
            <div key={i} style={{
              background:T.cream, border:`3px solid ${T.dark}`,
              borderRadius:16, padding:"16px 18px",
              boxShadow:`4px 4px 0 ${T.dark}`, marginBottom:10,
            }}>
              <div style={{ display:"flex", justifyContent:"space-between", alignItems:"flex-start", marginBottom:8 }}>
                <div>
                  <p style={{ fontSize:10, fontWeight:700, letterSpacing:1, textTransform:"uppercase", color:T.blue }}>
                    📍 {r.lugar} · {r.fecha}
                  </p>
                  <p style={{ fontSize:11, color:"#888", marginTop:2 }}>✍️ {r.autor}</p>
                </div>
                <button onClick={() => dispatch({ type:"REFLEXION_REMOVE", index:i })}
                  style={{ background:"none",border:"none",fontSize:16,color:"#ccc",cursor:"pointer" }}
                >✕</button>
              </div>
              <p style={{ fontFamily:"'Playfair Display',serif",fontStyle:"italic",fontSize:14,lineHeight:1.7,color:"#333" }}>
                "{r.texto}"
              </p>
            </div>
          ))
        )}
      </PageWrap>
    </div>
  );
}

function MusicaView() {
  return (
    <div className="fade-up">
      <SectionTitle>MÚSICA</SectionTitle>
      <PageWrap>
        <div style={{
          background:T.spotify, border:`3px solid ${T.dark}`,
          borderRadius:20, padding:"28px 22px",
          boxShadow:`6px 6px 0 ${T.dark}`, marginBottom:16, textAlign:"center",
        }}>
          <div style={{ fontSize:54, marginBottom:14 }}>🎵</div>
          <h3 style={{ fontFamily:"'Bebas Neue',sans-serif",fontSize:30,letterSpacing:2,color:"#fff",marginBottom:6 }}>
            La Playlist de Bali
          </h3>
          <p style={{ color:"rgba(255,255,255,0.8)",fontSize:13,marginBottom:18 }}>
            El soundtrack oficial del viaje de los 30.<br />
            Escanea el QR del dossier o pulsa para unirte.
          </p>
          <button
            onClick={() => window.open("https://open.spotify.com/playlist/7Gu0Wf9Mnf12P86jSqFwpu?si=Fx5WZ6tJTWSpMa47iTj1rA&pi=PCz-BS0ES1uCJ", "_blank")}
            style={{
              background:"#fff", color:T.spotify, border:"none",
              borderRadius:30, padding:"10px 26px",
              fontSize:13, fontWeight:700, cursor:"pointer",
              transition:"transform .15s",
            }}
            onMouseEnter={e => (e.currentTarget.style.transform = "scale(1.04)")}
            onMouseLeave={e => (e.currentTarget.style.transform = "")}
          >
            UNIRME A LA PLAYLIST
          </button>
        </div>
        <Card style={{ textAlign:"left" }}>
          <p style={{ fontFamily:"'Bebas Neue',sans-serif",fontSize:18,letterSpacing:1,marginBottom:10,color:T.blue }}>
            🎧 VIBE DEL VIAJE
          </p>
          <p style={{ fontSize:14,lineHeight:1.7,color:"#444" }}>
            Desde sunsets en Uluwatu hasta noches en Canggu.
            Añade tus canciones favoritas y construimos juntas el soundtrack de los 30. 🌺
          </p>
        </Card>
      </PageWrap>
    </div>
  );
}

/* ================================================================
   Section Router
   ================================================================ */
const VIEW_MAP: Record<string, any> = {
  home:        HomeView,
  viajeras:    ViajerasView,
  ruta:        RutaView,
  retos:       RetosView,
  normas:      NormasView,
  fotos:       FotosView,
  reflexiones: DiarioView,
  musica:      MusicaView,
};
function SectionRouter() {
  const { activeSection } = useApp();
  const ActiveView = VIEW_MAP[activeSection] || HomeView;
  return (
    <main style={{ paddingTop:54, paddingBottom:60, minHeight:"100vh" }}>
      <div style={{ padding:"16px 16px 0" }}>
        <ActiveView key={activeSection} />
      </div>
    </main>
  );
}

/* ================================================================
   App root
   ================================================================ */
function ClickConfetti() {
  const confetti = useConfetti();
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      // No confetti en inputs para no molestar al escribir
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) return;
      
      // Pequeña explosión en el punto del click
      const x = e.clientX;
      const y = e.clientY;
      for (let i = 0; i < 12; i++) {
        setTimeout(() => {
          const el = document.createElement("div");
          const color = CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)];
          const size = 5 + Math.random() * 6;
          const angle = Math.random() * 360;
          const distance = 20 + Math.random() * 40;
          Object.assign(el.style, {
            position: "fixed",
            left: `${x}px`,
            top: `${y}px`,
            width: `${size}px`,
            height: `${size}px`,
            background: color,
            borderRadius: "2px",
            pointerEvents: "none",
            zIndex: "9999",
            transform: `translate(-50%, -50%)`,
            animation: `confettiBurst 0.6s ease-out forwards`,
          });
          el.style.setProperty('--x', `${Math.cos(angle * Math.PI / 180) * distance}px`);
          el.style.setProperty('--y', `${Math.sin(angle * Math.PI / 180) * distance}px`);
          document.body.appendChild(el);
          setTimeout(() => el.remove(), 650);
        }, i * 15);
      }
    };
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, [confetti]);
  return null;
}

function InstallPrompt() {
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [showPrompt, setShowPrompt] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone) {
      setIsInstalled(true);
      return;
    }
    const handler = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
      setTimeout(() => setShowPrompt(true), 3000);
    };
    window.addEventListener('beforeinstallprompt', handler);
    const installedHandler = () => {
      setIsInstalled(true);
      setShowPrompt(false);
    };
    window.addEventListener('appinstalled', installedHandler);
    return () => {
      window.removeEventListener('beforeinstallprompt', handler);
      window.removeEventListener('appinstalled', installedHandler);
    };
  }, []);

  const handleInstall = async () => {
    if (!deferredPrompt) {
      alert('Para instalar en iPhone: toca Compartir ↗️ y luego "Añadir a pantalla de inicio"');
      return;
    }
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') setShowPrompt(false);
    setDeferredPrompt(null);
  };

  if (isInstalled || !showPrompt) return null;

  return (
    <div style={{
      position: 'fixed',
      bottom: 70,
      left: 12,
      right: 12,
      zIndex: 1000,
      background: T.cream,
      border: `3px solid ${T.dark}`,
      borderRadius: 16,
      padding: '14px 16px',
      boxShadow: `6px 6px 0 ${T.dark}`,
      animation: 'fadeUp 0.3s ease',
      maxWidth: 400,
      margin: '0 auto',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ fontSize: 32 }}>✈️</div>
        <div style={{ flex: 1 }}>
          <p style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: 18, letterSpacing: 1, marginBottom: 2 }}>
            ¡INSTALA BALI 30!
          </p>
          <p style={{ fontSize: 12, color: '#666', lineHeight: 1.3 }}>
            Descárgala para usar offline y que las 8 podáis interactuar
          </p>
        </div>
        <button
          onClick={handleInstall}
          style={{
            background: T.pink,
            border: `2px solid ${T.dark}`,
            color: '#fff',
            borderRadius: 10,
            padding: '8px 14px',
            fontSize: 12,
            fontWeight: 700,
            boxShadow: `2px 2px 0 ${T.dark}`,
            cursor: 'pointer',
            whiteSpace: 'nowrap',
          }}
        >
          INSTALAR
        </button>
        <button
          onClick={() => setShowPrompt(false)}
          style={{ background: 'none', border: 'none', fontSize: 18, color: '#999', cursor: 'pointer', padding: 4 }}
          aria-label="Cerrar"
        >
          ✕
        </button>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <GlobalStyles />
      <ClickConfetti />
      <InstallPrompt />
      <Nav />
      <SectionRouter />
      <style>{`
        @keyframes confettiBurst {
          0% { transform: translate(-50%, -50%) scale(0) rotate(0deg); opacity: 1; }
          100% { transform: translate(calc(-50% + var(--x)), calc(-50% + var(--y))) scale(1) rotate(720deg); opacity: 0; }
        }
      `}</style>
    </AppProvider>
  );
}